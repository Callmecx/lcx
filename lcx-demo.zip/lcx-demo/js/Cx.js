 (function anni(){
            var head = document.getElementById("head"),
                hmid = document.getElementById("headmid1"),
                p1 = document.getElementById("p1"),
                p2 = document.getElementById("p2"),
                p3 = document.getElementById("p3"),
                p4 = document.getElementById("p4"),
                bod = document.getElementById("bod"),
                content1 = document.getElementById("content1"),
                content2 = document.getElementById("content2"),
                numAll = document.getElementById("allnum").getElementsByTagName("h1"),
                clear =document.getElementById("clear1"),
                mid1 =document.getElementById("mid111"),
                n=0,
                m=1;
            function marginRandom(){
                return Math.floor(Math.random()*400+300);
            }
            function topRandom(){
                return Math.floor(Math.random()*(-400)+100);
            }
            function hRandom(){
                return Math.floor(Math.random()*10);
            }
            function num(){
                n++;
                bod.style.backgroundImage="url(../img/bg"+n+".jpg)";
                bod.style.transition="3s";
            clear1.onclick=function(){
                clearTimeout(clears);
                for(var i=0;i<numAll.length;i++){
                numAll[i].style.visibility="hidden";
                numAll[i].style.transition="1s";   
                }  
            }
            content1.onclick=function(){
                numAll[hRandom()].style.visibility="visible";
                numAll[hRandom()].style.marginLeft=marginRandom()+"px";
                numAll[hRandom()].style.marginTop=topRandom()+"px";
                m=m-0.1;
                content1.style.transform="scale("+m+")";
                content1.style.transition="1s";
                function moves(){
                numAll[hRandom()].style.visibility="visible";
                numAll[hRandom()].style.marginLeft=marginRandom()+"px";
                numAll[hRandom()].style.marginTop=topRandom()+"px";
                clears= setTimeout(moves,500);
                }
                moves();
                if(m<0.11){
                    m=1.5;
                  }
               }
                if(n>6){
                  n=0; 
               }
               setTimeout(num,5000);
            }   
            num();
            function fontChange(){
                content1.style.marginLeft="30%";
                content1.style.animation="left 2s"; 
            }
            fontChange();
            function headMove(){
                head.style.height="200px";
                head.style.transition="0.5s";
                }
            function headOut(){
                head.style.height="60px";
                head.style.transition="0.5s";
            }
            hmid.addEventListener("mouseover",headMove);
            hmid.addEventListener("mouseout",headOut);
        })();      
        window.onscroll=function(){
            var head = document.getElementById("head"),
                img1 = document.getElementById("img1"),
                img2 = document.getElementById("img2"),
                img3 = document.getElementById("img3"),
                mid1 =document.getElementById("mid111"),
                imgs =document.querySelectorAll(".imgs"),
                end = document.getElementById("end1").getElementsByTagName("h1"),
                imgtop =document.getElementById("imgtop"),
                scrollHead = document.documentElement.scrollTop || document.body.scrollTop;
                var n=-1;
        function allover(){
        if(scrollHead>1000){
            n++;
            end[n].style.visibility="visible";
            end[n].style.transition="1s";
            }
        if(n>35){
            n=-1;
            clearTimeout(cx);
        }
        cx= setTimeout(allover,500);
        }
        allover()
        if(scrollHead>1100){
            imgtop.style.marginTop="770px";
            imgtop.style.transition="1.5s";
        }
        if(scrollHead<1300){
            imgtop.style.marginTop="700px";
            imgtop.style.transition="1.5s";
        }
        if(scrollHead>60){
            head.style.display="block";
            head.style.position="fixed";
            head.style.animation="one 0.5s";
            }
        if(scrollHead<20){
            head.style.display="none";
        }
        if(scrollHead>250){
            img1.style.visibility="visible";
            img1.style.animation="imgs1 3s";
            img2.style.visibility="visible";
            img2.style.animation="imgs2 3s";
            img3.style.visibility="visible";
            img3.style.animation="imgs3 3s";
        }
        for(var i=0;i<imgs.length;i++){
        if(scrollHead>780){   
            imgs[i].style.marginTop="150px";
            imgs[i].style.transition="1s";
        }
        if(scrollHead<850){
            imgs[i].style.marginTop="0px" ;
        }
        }
        }
        window.addEventListener('load', function () {
		var carousels = document.querySelectorAll('.carousel');

		for (var i = 0; i < carousels.length; i++) {
			carousel(carousels[i]);
		}
	});

	function carousel(root) {
		var figure = root.querySelector('figure'),
			nav = root.querySelector('nav'),
			images = figure.children,
			n = images.length,
			gap = root.dataset.gap || 0,
			bfc = 'bfc' in root.dataset,
			theta = 2 * Math.PI / n,
			currImage = 0;

		setupCarousel(n, parseFloat(getComputedStyle(images[0]).width));
		window.addEventListener('resize', function () {
			setupCarousel(n, parseFloat(getComputedStyle(images[0]).width));
		});

		setupNavigation();

		function setupCarousel(n, s) {
			var apothem = s / (2 * Math.tan(Math.PI / n));

			figure.style.transformOrigin = '50% 50% ' + -apothem + 'px';

			for (var i = 0; i < n; i++) {
				images[i].style.padding = gap + 'px';
			}for (i = 1; i < n; i++) {
				images[i].style.transformOrigin = '50% 50% ' + -apothem + 'px';
				images[i].style.transform = 'rotateY(' + i * theta + 'rad)';
			}
			if (bfc) {for (i = 0; i < n; i++) {
				images[i].style.backfaceVisibility = 'hidden';
			}
		}rotateCarousel(currImage);
		}
		function setupNavigation() {
			nav.addEventListener('click', onClick, true);

			function onClick(e) {
				e.stopPropagation();

				var t = e.target;
				if (t.tagName.toUpperCase() != 'BUTTON') return;

				if (t.classList.contains('next')) {
					currImage++;
				} else {
					currImage--;
				}

				rotateCarousel(currImage);
			}
		}
		function rotateCarousel(imageIndex) {
			figure.style.transform = 'rotateY(' + imageIndex * -theta + 'rad)';
		}
	}