function topChange(){
    var img =document.getElementById("end"),
        body =document.getElementById("bod"),
        p1 =document.getElementById("p1"),
        p2 =document.getElementById("p2"),
        p3 =document.getElementById("p3"),
        head = document.getElementById("hed"),
        title = document.querySelector(".titleTop"),
        title2 = document.querySelectorAll(".title2"),
        n=0;
    p1.onclick=function(){
        clearTimeout(over);
        clearTimeout(over2);
        clearTimeout(over3);
        body.style.backgroundImage="url('../img/1.jpg')";
        body.style.transition="2s";
        p1.style.transition="1s";
    }
    p2.onclick=function(){
        clearTimeout(over);
        clearTimeout(over2);
        clearTimeout(over3);
        body.style.backgroundImage="url('../img/2.jpg')";
        body.style.transition="2s";
        p2.style.transition="1s";
    }
    p3.onclick=function(){
        clearTimeout(over);
        clearTimeout(over2);
        clearTimeout(over3);
        body.style.backgroundImage="url('../img/3.jpg')";
        body.style.transition="2s";
        p2.style.transition="1s";
    }
    function imgsChange(){
        n++;
        var m="../img/"+n+".jpg";
        body.style.backgroundImage="url("+m+")";
        body.style.transition="2s";
      if(n>2){
        n=0;
        }
        over = setTimeout(imgsChange,5100);
    }
    imgsChange();
    function progress(){
        p1.style.width="100px";
        p1.style.backgroundColor="white";
        p1.style.animation="one 5s"; 
        over2= setTimeout(progress2,15500)
        over3= setTimeout(progress,15551);
    }
    function progress2(){
        p1.style.width="0px";
        p1.style.backgroundColor="rgba(19, 12, 26, 0.151)";
        p1.style.animation="two 0.01s";
        p2.style.backgroundColor="rgba(19, 12, 26, 0.151)";
        p3.style.backgroundColor="rgba(19, 12, 26, 0.151)";
    }
    progress(); 
    function progress3(){
        p2.style.width="0px";
        p2.style.animation="two 0.01s";
    }
    function progress33(){
        p2.style.width="100px";
        p2.style.backgroundColor="white";
        p2.style.animation="one 5s";
        setTimeout(progress3,15310)
        setTimeout(progress33,15400);
    }
    setTimeout(progress33,5200)
    function progress4(){
        p3.style.width="0px";
        p3.style.animation="two 0.01s";
    }
    function progress44(){
        p3.style.width="100px";
        p3.style.backgroundColor="white";
        p3.style.animation="one 5s";
        setTimeout(progress4,15320)
        setTimeout(progress44,15399);
    }
    setTimeout(progress44,10400)
    title.onmouseover=function(){
        head.style.height="200px";
        head.style.transition="0.5s";
        head.style.backgroundColor="rgba(0, 0, 0, 0.830)";
    }
    title.onmouseout=function(){
        head.style.height="60px";
        head.style.backgroundColor="rgba(0, 0, 0, 0.836)";
        }  
    }
    topChange();